Notes:

I typed in the FEL-1 listing from the BJC papers - including 1802 Assembler and the objec code.
This file is fel.src

The file process.py takes this and converts it to an assembler only file fel.asm and a binary file
fel_src.bin

This source file is assembled using Alfred Arnold's AS freeware assembler and compared against the typed
in binary code.

TODO: Rename the labels to something other than Lxxxx

Paul Robson 12 July 2016

